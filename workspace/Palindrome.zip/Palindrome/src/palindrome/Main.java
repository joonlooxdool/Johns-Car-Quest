package palindrome;

public class Main {

	public static void main(String[] args) {
		
		Summation c = new Summation();
		prime10001 b = new prime10001();
		SmallestMult d = new SmallestMult();
		System.out.println(b.method(0));
		System.out.println(c.method(0));
		System.out.println(d.method(0));
	}

}
